# -*- coding: utf-8 -*-
# @author: NiHao

from searwhoo.server import main


if __name__ == '__main__':
    main()