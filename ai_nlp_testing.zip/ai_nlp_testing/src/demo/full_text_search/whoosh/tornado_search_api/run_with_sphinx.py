# -*- coding: utf-8 -*-
# @author: NiHao

from searsphi.server import main


if __name__ == '__main__':
    main()