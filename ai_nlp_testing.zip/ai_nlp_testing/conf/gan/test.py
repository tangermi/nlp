# -*- coding: utf-8 -*-

CONFIG = {
    'name': 'gan',
    'task': [
        'gan'
    ],
    'gan': {
        'hist_path': '/apps/data/ai_nlp_testing/gan/train/acgan-history.pkl',
        'last_epoch': '/apps/data/ai_nlp_testing/gan/train/params_generator_epoch_015.hdf5'
    },
}
