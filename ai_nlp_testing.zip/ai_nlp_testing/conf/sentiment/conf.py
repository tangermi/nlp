# -*- coding: utf-8 -*-

CONFIG = {
    'name': 'sentiment',
    'task': [
        # 'preprocess',
        'feature',
        # 'train',
        # 'predict',
        # 'evaluation'
    ],
}
